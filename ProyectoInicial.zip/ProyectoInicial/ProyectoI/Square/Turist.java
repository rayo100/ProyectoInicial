
/**
 * La clase Turist es
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Turist{
    
    private boolean isVisible;

    /**
     * Constructor for objects of class Turist
     */
    public Turist(){
        
    }

    /**
     * Este metodo hace visible el turista
     */
    public void makeVisible(){
        isVisible = true;
        //visual.makeVisible();
        //if(conquered)marca.makeVisible();
    }
    /**
     * Este metodo hace invisible el turista
     */
    public void makeInvisible(){
        isVisible = false;
        //marca.makeInvisible();
        //visual.makeInvisible();
    }
}
