
/**
 * La clase Dome es .
 * 
 * @author (Poveda - Vásquez) 
 * @version (1.0 - 10-02-2022)
 */
public class Dome{
    private final int ANCHO = 20;
    private final int ALTO = 20;
    private String color;
    private int xPosition,yPosition;
    private Rectangle square;
    private Rectangle visual;
    private boolean isVisible;

    /**
     * Constructor for objects of class Dome
     */
    public Dome(String color, int x, int y, Rectangle square){
        this.color = color;
        this.square = square;
        this.xPosition = getPositionX(x);
        this.yPosition = getPositionY(y);
        isVisible = false;
        visual = new Rectangle(ANCHO,ALTO);
        configureVisual();
    }

    /**
     * Este metodo localiza la cupula en la plaza
     * con el respectivo color y posicion
     */
    public void configureVisual(){
        visual.changeColor(color);
        visual.changePosition(xPosition, yPosition);
    }
    /**
     * Este metodo actualiza las cupulas
     */
    public void update(){        
        configureVisual();
        if (isVisible) makeVisible();
    }
    /**
     * Este metodo hace visible la cupula
     */
    public void makeVisible(){
        isVisible = true;
        visual.makeVisible();
        //if(conquered)marca.makeVisible();
    }
    /**
     * Este metodo hace invisible la cupula
     */
    public void makeInvisible(){
        isVisible = false;
        visual.makeInvisible();
    }
    
    
    /*
     * Este metodo retorna la coordenada Y de la cupula en la plaza
     * @ param yPosition, es la coordenada Y de la nacion
     */
    private int getPositionY(int yPosition){
        int total = square.getHeight();
        if (yPosition == 0) return total - yPosition + square.getYPosition() - ALTO;
        return total - yPosition + square.getYPosition();
    }
    /*
     * Este metodo retorna la coordenada X de la cupula en la plaza 
     * @ param xPosition, es la coordenada X de la nacion
     */
    private int getPositionX(int xPosition){
        int total = square.getXPosition();
        if (xPosition == 0) return total + xPosition;
        return total + xPosition-ANCHO;
    }
    /**
     * Este metodo retorna el color de la cupula
     * @ return color, es el identificador de la cupula
     */
    public String getColor(){
        return this.color;
    }
    
}
