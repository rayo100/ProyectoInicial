import java.util.*;

/**
 * La clase Square es .
 * 
 * @author (Poveda - Vásquez) 
 * @version (1.0 - 10-02-2022)
 */
public class Square{
    private Rectangle square;
    private ArrayList<Dome> domes = new ArrayList<Dome>();
    private ArrayList<Turist> turists;
    private int safetyDistance;
    private boolean isVisible;
    private boolean completado;
    /**
     * Constructor de la clase Square
     */
    public Square(int dimensionX, int dimensionY, int safetyDistance){
        this.square = new Rectangle(dimensionX, dimensionY);
        
        
    }
    /**
     * Este metodo adiciona un domo a la plaza en un lugar dado por el usuario
     * @ param color, es el identificador del domo
     * @ param x, es la posicion x del domo
     * @ param y, es la posicion y del domo
     */
    public void addDome(String color, int x, int y){
        Dome cupula = new Dome(color, x, y, square);
        domes.add(cupula);
    }
    /**
     * Este metodo elimina un domo de la plaza por su identificador
     * @ param color, es el identificador del domo
     */
    public void delDome(String color){
        Dome cupula = searchDome(color);
        if (cupula != null){
            domes.remove(cupula);
            update();
        }
        // else {
            // System.out.println("ERROR: No se encontró la cupula!");
        // }
    }
    /**
     * 
     */
    public void touristArrive(String color, int x, int y){
    
    }
    /**
     * 
     */
    public void turistMove(String tourist, int x, int y, int angle){
        
    }
    // public String[] touristTakePhoto(String tourist){
        
    // }
    // public String[] touristTakePhoto(String tourist,int viewInAngle){
        
    // }
    // public String[] domes(){
    
    // }
    // public String[] turists(){
    
    // }
    // public int[] dome(String dome){
    
    // }
    // public int[] turist(String tourist){
    
    // }
    /**
     * Este metodo hace visible la plaza
     */
    public void makeVisible(){
        isVisible = true;
        square.makeVisible();
        for(Dome i: domes) i.makeVisible();
        //for(Turist i: turists) i.makeVisible();
        completado = true;
    }
    /**
     * Este metodo hace invisible la plaza
     */
    public void makeInvisible(){
        isVisible = false;
        square.makeInvisible();
        //for(Dome i: domes) i.makeInvisible();
        //for(Turist i: turists) i.makeInvisible();
        completado = true;
    }
    /**
     * Este metodo finaliza cualquier accion que se este haciendo
     */
    public void finish(){
        System.exit(0);
    }
    /**
     * Este metodo retorna si la ultima accion could be done or not
     * @ return completado, true si se pudo hacer la ultima accion o false de lo contrario
     */
    public boolean ok(){
        return completado;
    }
    
    /*
     * Este metodo actualiza el simulador
     */
    private void update(){
        completado = true;
        if (isVisible) makeVisible();
    }
    /*
     * Este metodo busca la cupula por color
     * @ param color, es el color de la cupula
     */
    private Dome searchDome(String color){
        for (Dome i: domes){
            if (i.getColor().equals(color)) return i;
        }
        return null;
    }
}
