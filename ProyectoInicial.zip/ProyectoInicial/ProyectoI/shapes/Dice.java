import java.util.*;
/**
 * Se crea la figura de un dado usanado las clases Rectangle y Circle, se puede interactuar con él; cambiando color, tamaño, dando coordenadas de posición, 
 * moviendolo.
 * 
 * @author Poveda - Vásquez. 
 * @version 04/01/2022
 */
public class Dice
{
    // instance variables
    private byte digit;
    private Rectangle contorno;
    private Rectangle interno;
    private Circle punto1;
    private Circle punto2;
    private Circle punto3;
    private Circle punto4;
    private Circle punto5;
    private Circle punto6;
    private boolean isVisible;
    private ArrayList<Circle> puntos = new ArrayList<Circle>(); //Creación de un arreglo de objetos.
    private int x,y;
    // Mini-ciclo 1
    /** 
     * Es el constructor de los objetos (contorno y interno).
     * @param digito,es el digito del dado con el que se quiere contruir.
     */
    public Dice(byte digito)
    {
        digit = digito;
        contorno= new Rectangle(160,160,"black",0,0);
        interno= new Rectangle(140,140,"white",10,10);
    }
    // Mini-ciclo 2
    /**
     * Retorna el número actual que se muestra en el dado.
     * @return numero
     */
    public byte get(){
        return digit;
    }
    /**
     * Mira el siguiente digito y lo pinta
     */
    public void next(){
        if(digit!= 6) digit++;
        else digit = 1;
        makeVisible();
    }
    //mini-ciclo 3
    /**
     * Cambia el numero en el dado
     * @ param digito, es el nuevo digito
     */
    public void change(byte digito){
        digit = digito;
        makeVisible();
    }
    /**
     * Escoje un digito aleatoriamente
     */
    public void change(){
        digit = (byte)(Math.random()*7);
        makeVisible();
    }
    /**
     * Vuelve cada uno de los objetos necesarios del dado visibles (Contorno, interno y puntos).
     */
    public void makeVisible(){
        contorno.makeVisible();
        interno.makeVisible();
        if(digit != 0) mostrar();//Llama al metodo mostrar() para hacer visibles los puntos.
    }
    
    /**
     * Vuelve cada uno de los objetos necesarios del dado invisibles (Contorno, interno y puntos).
     */
    public void makeInvisible(){
        contorno.makeInvisible();
        interno.makeInvisible();
        borrar(); //Llama al metodo borrar() para hacer invisibles los puntos.
    }
    /**
     * Mueve el dado a la posición dada por x, y
     * @param Un int x, el cual indica cuanto sera el desplazamiento horizontal.
     * @param Un int y, el cual indica cuanto sera el desplazamiento vertical.
     */
    public void moveTo(int x, int y){
        this.x += x;
        this.y += y;
        contorno.moveHorizontal(x);
        interno.moveHorizontal(x);
        contorno.moveVertical(x);
        interno.moveVertical(y);
        for(Circle i : puntos){
            i.moveHorizontal(x);
            i.moveVertical(y);
        }
    }    
    
    /**
     * Cambia el color del contorno del dado.
     * @param Color, Los colores validos son "red", "yellow","magenta", "blue", "green".
     */
    public void changeColor(String _color){
        contorno.changeColor(_color);
        for(Circle i : puntos){
            i.changeColor(_color);
        }
        makeVisible();
    }

    /**
     * Muestra los puntos del arreglo de objetos (puntos).
     */
    private void mostrar(){
        puntos();
        for(Circle i : puntos){
            i.makeVisible();
        }
    }
    /**
     * Borra los puntos del arreglo de objetos (puntos).
     */
    private void borrar(){
        for(Circle i : puntos){
            i.makeInvisible();
        }
    }
    
    private void puntos(){
        //int n = (int) (Math.random() * (7 - 1)) + 1; // Número aleatorio del 1-6 usando random.
        puntos.clear();//Limpia valor anterior.
        if (digit==1){
            uno();
        }
        else if(digit==2){
            dos();
        }
        else if(digit==3){
            tres();
        }
        else if(digit==4){
            cuatro();
        }
        else if(digit==5){
            cinco();
        }
        else if(digit==6){
            seis();
        }
    }
    
    /**
     * Crea cara del dado con valor 1, y lo agrega al arreglo de objetos (puntos). Ubicando puntos en posición x, y.
     */
    private void uno(){
        punto1 = new Circle(x+65,y+65);
        puntos.add(punto1);
    }
    /**
     * Crea cara del dado con valor 2, y lo agrega al arreglo de objetos (puntos). Ubicando puntos en posición x, y.
     */
    private void dos(){
        punto1 = new Circle(x+15,y+15);
        punto2 = new Circle(x+115,y+115);
        puntos.add(punto1);
        puntos.add(punto2);
    }
    /**
     * Crea cara del dado con valor 3, y lo agrega al arreglo de objetos (puntos). Ubicando puntos en posición x, y.
     */
    private void tres(){
        punto1 = new Circle(x+15,y+15);
        punto2 = new Circle(x+115,y+115);
        punto3 = new Circle(x+65,y+65);
        puntos.add(punto1);
        puntos.add(punto2);
        puntos.add(punto3);
    }
    /**
     * Crea cara del dado con valor 4, y lo agrega al arreglo de objetos (puntos). Ubicando puntos en posición x, y.
     */
    private void cuatro(){
        punto1 = new Circle(x+15,y+15);
        punto2 = new Circle(x+115,y+115);
        punto3 = new Circle(x+115,y+15);
        punto4 = new Circle(x+15,y+115);
        puntos.add(punto1);
        puntos.add(punto2);
        puntos.add(punto3);
        puntos.add(punto4);
    }
    /**
     * Crea cara del dado con valor 5, y lo agrega al arreglo de objetos (puntos). Ubicando puntos en posición x, y.
     */
    private void cinco(){
        punto1 = new Circle(x+15,y+15);
        punto2 = new Circle(x+115,y+115);
        punto3 = new Circle(x+115,y+15);
        punto4 = new Circle(x+15,y+115);
        punto5 = new Circle(x+65,y+65);
        puntos.add(punto1);
        puntos.add(punto2);
        puntos.add(punto3);
        puntos.add(punto4);
        puntos.add(punto5);
    }
    /**
     * Crea cara del dado con valor 6, y lo agrega al arreglo de objetos (puntos). Ubicando puntos en posición x, y.
     */
    private void seis(){
        punto1 = new Circle(x+15,y+15);
        punto2 = new Circle(x+115,y+115);
        punto3 = new Circle(x+115,y+15);
        punto4 = new Circle(x+15,y+115);
        punto5 = new Circle(x+15,y+65);
        punto6 = new Circle(x+115,y+65);
        puntos.add(punto1);
        puntos.add(punto2);
        puntos.add(punto3);
        puntos.add(punto4);
        puntos.add(punto5);
        puntos.add(punto6);
    } 
}
